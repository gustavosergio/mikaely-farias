# Mikaely Farias — Psicologia & Sexologia

Site responsivo em React, TypeScript, Vite e Tailwind CSS. Execute `npm install` e `npm run dev`. Para gerar a versão estática: `npm run build`.

Fotos públicas obtidas do perfil https://www.instagram.com/psimikaely/ em 06/11/2026. Os arquivos locais evitam depender dos links temporários do Instagram. Foto principal: reel DMQDMzNOO__; foto em encontro profissional: post DUQv3gLETtk. Dados profissionais, WhatsApp, endereço e atendimento às quintas-feiras fornecidos pelo solicitante. Nenhum depoimento ou resultado clínico foi inventado.

## GitHub Pages
Site: https://gustavosergio.github.io/mikaely-farias/
Publicação: branch main, pasta /docs. Após alterar o código, execute npm run build e copie o conteúdo de dist para docs antes do commit.
